package com.dshop.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
