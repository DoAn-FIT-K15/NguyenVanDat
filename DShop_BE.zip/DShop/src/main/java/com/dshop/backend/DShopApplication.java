package com.dshop.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(DShopApplication.class, args);
	}

}
